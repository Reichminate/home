<?= $yield_topscript; ?>
<body id="body">
    <?= $yield_topbar; ?>
    <?= $yield_navbar; ?>
    <?= $yield; ?>
    <?= $yield_footer; ?>
    <a href="#" class="back-to-top">
        <i class="fa fa-chevron-up"></i>
    </a>
    <?= $yield_bottomscript; ?>
</body>

</html>
