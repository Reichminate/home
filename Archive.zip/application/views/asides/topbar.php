<section id="topbar" class="d-none d-lg-block">
    <div class="container clearfix">
        <div class="contact-info float-left">
            <i class="fa fa-envelope-o"></i> 
            <a href="mailto:hi@reichminate.com">hi@reichminate.com</a>
            <i class="fa fa-phone"></i> +62 823 8800 0124
        </div>
        <div class="social-links float-right">
            <a href="https://www.linkedin.com/company/reichminate" class="linkedin">
                <i class="fa fa-linkedin"></i>
            </a>
        </div>
    </div>
</section>