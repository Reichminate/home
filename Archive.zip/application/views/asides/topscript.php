<head>
    <meta charset="utf-8">
    <title>Reichminate</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <link href="<?= assets_url('img/company_icon.png'); ?>" rel="icon">
    <link href="<?= assets_url('img/apple-touch-icon.png'); ?>" rel="apple-touch-icon">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800|Montserrat:300,400,700" rel="stylesheet">
    <link href="<?= assets_url('lib/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('lib/font-awesome/css/font-awesome.min.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('lib/animate/animate.min.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('lib/ionicons/css/ionicons.min.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('lib/owlcarousel/assets/owl.carousel.min.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('lib/magnific-popup/magnific-popup.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('lib/ionicons/css/ionicons.min.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('css/style.css'); ?>" rel="stylesheet">
    <link href="<?= assets_url('css/all.css'); ?>" rel="stylesheet">
    <style>
        #map {
            width: 100%;
            height: 400px;
        }
    </style>
</head>