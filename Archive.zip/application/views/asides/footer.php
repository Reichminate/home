<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright. <?php echo date("Y"); ?> Reichminate
        </div>
    </div>
</footer>